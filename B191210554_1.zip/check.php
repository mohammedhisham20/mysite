
<?php
if (isset($_POST['adi'], $_POST['password'] )
&& ($_POST['adi']!='')
&& ($_POST['password']!=''))
{

	echo "HoşGeldiniz...".' '.$_POST['adi'];
	
}


?>
